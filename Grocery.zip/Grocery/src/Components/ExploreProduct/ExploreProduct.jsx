import React, { useState } from 'react';
import './ExploreProduct.css';
import { menu_list } from '../../assets/assets';

const ExploreProduct = () => {
    const [category, setCategory] = useState("All");

    return (
        <div className='explore-product' id='explore-product'>
            <h1>Explore our products</h1>
            <p className='explore-product-text'>
                Explore our product to discover its powerful features designed to simplify your tasks and boost productivity. Experience seamless performance and see how it can transform your workflow.
            </p>
            <div className="explore-product-list">
                {menu_list.map((item, index) => {
                    return (
                        <div 
                            key={index} 
                            className='explore-menu-list-item' 
                            onClick={() => setCategory(item.menu_name)} // Set the clicked item as active
                        >
                            <img 
                                className={category === item.menu_name ? "active" : ""} 
                                src={item.menu_image} 
                                alt={item.menu_name} 
                            />
                            <p>{item.menu_name}</p>
                        </div>
                    );
                })}
            </div>
            <hr />
        </div>
    );
}

export default ExploreProduct;