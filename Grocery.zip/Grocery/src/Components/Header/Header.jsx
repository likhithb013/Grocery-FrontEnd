import React from 'react'
import './Header.css'

const Header = () => {
  return (
    <div className='header'>
        <div className="header-contents">
            <h2>Order your favourite Product here</h2>
            <p>Explore a diverse selection of fresh and high-quality groceries, sourced from trusted suppliers. Whether you're stocking your pantry or planning your next meal, our wide range of products ensures that every ingredient meets the highest standards. Elevate your cooking and enjoy the convenience of shopping for all your essentials in one place.</p>
            <button>View Product</button>
        </div>
      
    </div>
  )
}

export default Header
