import React, { useState } from "react";
import "./Home.css";
import Header from "../../Components/Header/Header";
import ExploreProduct from "../../Components/ExploreProduct/ExploreProduct";
import FoodDisplay from "../../FoodDisplay/FoodDisplay";
import AppDownload from "../../Components/AppDownload/AppDownload";

const Home = () => {
  const [category, serCategory] = useState("All");

  return (
    <div>
      <Header />
      <ExploreProduct category={category} serCategory={serCategory} />
      <FoodDisplay category={category} />
      <AppDownload />
    </div>
  );
};

export default Home;
