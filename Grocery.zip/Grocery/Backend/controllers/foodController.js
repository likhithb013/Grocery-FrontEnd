import foodModel from "../models/foodModel.js";
import fs from 'fs'

// add food item

const addFood = async (req,res) => {


}

export {addFood}