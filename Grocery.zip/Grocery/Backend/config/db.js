import mongoose from "mongoose";

export    const connectDB = async () => {
    await mongoose.connect('mongodb+srv://likhithsagar189:AFtkpqsBB0PMC1bf@cluster0.tg38t.mongodb.net/Grocery').then(()=>console.log("DB Connected"));
}
